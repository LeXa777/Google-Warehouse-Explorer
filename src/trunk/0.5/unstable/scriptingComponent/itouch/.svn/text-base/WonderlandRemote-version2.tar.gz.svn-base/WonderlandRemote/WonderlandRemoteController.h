//
//  WonderlandRemoteController.h
//  WonderlandRemote
//
//  Created by Morris Ford on 4/5/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class		AsyncSocket;

@interface WonderlandRemoteController : UIViewController <UITextFieldDelegate> {
	UILabel			*ipLabel;
	UITextField		*ipText;
	UILabel			*portLabel;
	UITextField		*portText;
	UIButton		*startStop;
	UISwitch		*listenConnect;
	UILabel			*objectLabel;
	UITextField		*objectText;
	UIButton		*startStopObject;
	UIScrollView	*logScroll;
	UITextView		*logText;
	UIButton		*connect;
	
	AsyncSocket		*listenSocket;
	NSMutableArray	*connectedSockets;
	AsyncSocket		*talkSocket;
	AsyncSocket		*callSocket;
	
	BOOL			isRunning;
	BOOL			ani1Running;
	BOOL			ani2Running;
}

@property (nonatomic, retain) IBOutlet  UILabel			*ipLabel;
@property (nonatomic, retain) IBOutlet  UITextField		*ipText;
@property (nonatomic, retain) IBOutlet  UILabel			*portLabel;
@property (nonatomic, retain) IBOutlet  UITextField		*portText;
@property (nonatomic, retain) IBOutlet  UIButton		*startStop;
@property (nonatomic, retain) IBOutlet  UISwitch		*listenConnect;
@property (nonatomic, retain) IBOutlet  UILabel			*objectLabel;
@property (nonatomic, retain) IBOutlet  UITextField		*objectText;
@property (nonatomic, retain) IBOutlet  UIButton		*startStopObject;
@property (nonatomic, retain) IBOutlet  UIScrollView	*logScroll;
@property (nonatomic, retain) IBOutlet	UITextView		*logText;
@property (nonatomic, retain) IBOutlet	UIButton		*connect;

- (IBAction)startStop:(id)sender;
- (IBAction)startStopObject:(id)sender;
- (BOOL)textFieldShouldReturn:(UITextField *)theTextField;
- (IBAction)connect:(id)sender;
- (IBAction)listenConnect:(id)sender;

@end
