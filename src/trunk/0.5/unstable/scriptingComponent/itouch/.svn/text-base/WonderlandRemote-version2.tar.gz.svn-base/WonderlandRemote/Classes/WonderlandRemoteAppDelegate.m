//
//  WonderlandRemoteAppDelegate.m
//  WonderlandRemote
//
//  Created by Morris Ford on 4/5/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "WonderlandRemoteAppDelegate.h"
#import "WonderlandRemoteController.h"

@implementation WonderlandRemoteAppDelegate

@synthesize window;
@synthesize wonderlandRemoteController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
	WonderlandRemoteController *wViewController = [[WonderlandRemoteController alloc]
			 initWithNibName:@"WonderlandRemoteController" bundle:[NSBundle mainBundle]];
	self.wonderlandRemoteController = wViewController;
	[wViewController release];    // Override point for customization after application launch
	UIView *controllersView = [wonderlandRemoteController view];
	[window addSubview:controllersView];
    [window makeKeyAndVisible];
}


- (void)dealloc {
	[wonderlandRemoteController release];
    [window release];
    [super dealloc];
}


@end
