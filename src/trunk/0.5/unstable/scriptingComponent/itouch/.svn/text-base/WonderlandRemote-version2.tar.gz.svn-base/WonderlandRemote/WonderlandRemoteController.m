//
//  WonderlandRemoteController.m
//  WonderlandRemote
//
//  Created by Morris Ford on 4/5/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "WonderlandRemoteController.h"
#import "AsyncSocket.h"

@implementation WonderlandRemoteController

@synthesize			ipLabel;
@synthesize			ipText;
@synthesize			portLabel;
@synthesize			portText;
@synthesize			startStop;
@synthesize			listenConnect;
@synthesize			objectLabel;
@synthesize			objectText;
@synthesize			startStopObject;
@synthesize			logScroll;
@synthesize			logText;
@synthesize			connect;

- (IBAction)listenConnect:(id)sender
{
	if(listenConnect.on)
		NSLog (@"listenConnect on");
	else
		NSLog (@"ListenConnect off");
}

- (IBAction)connect:(id)sender
	{
		if(!listenConnect.on)
		    {
			int port = [portText.text intValue];
			NSLog (@"Port set to %d for connect", port);
			NSLog (@"IP set to %@ for connect", ipText.text);
			callSocket = [[AsyncSocket alloc] initWithDelegate:self];
			[callSocket connectToHost: ipText.text onPort: port error: nil];
			}
		else
			{
			NSLog (@"Cannot connect listen/connect is set to listen");
			}
	}

- (IBAction)startStop:(id)sender
{
	if(!isRunning)
		{
		int port = [portText.text intValue];
		NSLog (@"Port set to %d", port);
			
		if(port < 0 || port > 65535)
			{
			port = 0;
			}
		listenSocket = [[AsyncSocket alloc] initWithDelegate:self];
		connectedSockets = [[NSMutableArray alloc] initWithCapacity:1];
		
		isRunning = NO;
		ani1Running = NO;
		ani2Running = NO;
			
		NSError *error = nil;
		if(![listenSocket acceptOnPort:port error:&error])
			{
			NSLog (@"Error starting Wonderland Remote: %d", error);
				return;
			}
			
		NSLog(@"Wonderland Remote started on port %hu", [listenSocket localPort]);
		isRunning = YES;
			
		[portText setEnabled:NO];
		[startStop setTitle:@"Stop" forState:UIControlStateNormal];
		}
	else
		{
			// Stop accepting connections
		[listenSocket disconnect];
			
			// Stop any client connections
		int i;
		for(i = 0; i < [connectedSockets count]; i++)
			{
				// Call disconnect on the socket,
				// which will invoke the onSocketDidDisconnect: method,
				// which will remove the socket from the list.
			[[connectedSockets objectAtIndex:i] disconnect];
			}
			
		NSLog (@"Stopped Wonderland Remote");
		isRunning = false;
			
		[portText setEnabled:YES];
		[startStop setTitle:@"Start" forState:UIControlStateNormal];
		}
	}

- (IBAction)startStopObject:(id)sender
{
	
	NSLog (@"Object = %@", objectText.text);
	int object = [objectText.text intValue];
	if(object == 1)
		{
		if(ani1Running == NO)
			{
			NSString *msg = @"00014400,start";
			NSLog (@"Sending %@", msg);
			NSData *myMsg = [msg dataUsingEncoding:NSUTF8StringEncoding];
//			AsyncSocket *mySocket = [connectedSockets objectAtIndex:0];
			if(listenConnect.on)
			    [talkSocket writeData:myMsg withTimeout:-1 tag:0];
			else
				[callSocket writeData:myMsg	withTimeout:-1 tag:0];
			ani1Running = YES;
			}
		else
			{
			NSString *msg = @"00013400,stop";
			NSLog (@"Sending %@", msg);
			NSData *myMsg = [msg dataUsingEncoding:NSUTF8StringEncoding];
//			AsyncSocket *mySocket = [connectedSockets objectAtIndex:0];
			if(listenConnect.on)
				[talkSocket writeData:myMsg withTimeout:-1 tag:0];
			else
				[callSocket writeData:myMsg	withTimeout:-1 tag:0];
			ani1Running = NO;
			}
		}
	else if(object == 2)
		{
		if(ani2Running == NO)
			{
			NSString *msg = @"00014401,start";
			NSLog (@"Sending %@", msg);
			NSData *myMsg = [msg dataUsingEncoding:NSUTF8StringEncoding];
//			AsyncSocket *mySocket = [connectedSockets objectAtIndex:0];
			if(listenConnect.on)
				[talkSocket writeData:myMsg withTimeout:-1 tag:0];
			else
				[callSocket writeData:myMsg	withTimeout:-1 tag:0];
			ani2Running = YES;
			}
		else
			{
			NSString *msg = @"00013401,stop";
			NSLog (@"Sending %@", msg);
			NSData *myMsg = [msg dataUsingEncoding:NSUTF8StringEncoding];
//			AsyncSocket *mySocket = [connectedSockets objectAtIndex:0];
			if(listenConnect.on)
				[talkSocket writeData:myMsg withTimeout:-1 tag:0];
			else
				[callSocket writeData:myMsg	withTimeout:-1 tag:0];
			ani2Running = NO;
			}
		}
	else
	{
		NSLog (@"Try to start an object - %d", object);
	}
}

- (void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket
{
	[connectedSockets addObject:newSocket];
	talkSocket = newSocket;
}

- (void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port
{
	NSLog (@"Accepted client %@:%hu", host, port);
	
	NSString *welcomeMsg = @"00050Welcome to the Wonderland iTouch Remote test\r\n";
	NSData *welcomeData = [welcomeMsg dataUsingEncoding:NSUTF8StringEncoding];
	
	[sock writeData:welcomeData withTimeout:-1 tag:0];
}

- (void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
	NSData *strData = [data subdataWithRange:NSMakeRange(0, [data length] - 2)];
	NSString *msg = [[[NSString alloc] initWithData:strData encoding:NSUTF8StringEncoding] autorelease];
	if(msg)
	{
		NSLog (@"Received message on socket %d", sock);
		NSLog (msg);
	}
	else
	{
		NSLog (@"Error converting received data into UTF-8 String");
	}
	
	// Even if we were unable to write the incoming data to the log,
	// we're still going to echo it back to the client.
	[sock writeData:data withTimeout:-1 tag:0];
	
}

- (void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag
{
	[sock readDataToData:[AsyncSocket CRLFData] withTimeout:-1 tag:0];
}

- (void)onSocket:(AsyncSocket *)sock willDisconnectWithError:(NSError *)err
{
	NSLog (@"Client Disconnected: %@:%hu", [sock connectedHost], [sock connectedPort]);
}

- (void)onSocketDidDisconnect:(AsyncSocket *)sock
{
	[connectedSockets removeObject:sock];
}


- (id)init
{
	if(self = [super init])
	{
		listenSocket = [[AsyncSocket alloc] initWithDelegate:self];
		connectedSockets = [[NSMutableArray alloc] initWithCapacity:1];
		
		isRunning = NO;
//		ani1IsRunning = NO;
//		ani2IsRunning = NO;
	}
	return self;
}



- (BOOL)textFieldShouldReturn:(UITextField *)theTextField 
	{
	NSLog (@"Inside ipTextShouldReturn");
    if (theTextField == ipText) 
		{
        [ipText resignFirstResponder];
		}
	else if (theTextField == portText)
		{
		[portText resignFirstResponder];
		}
	else if (theTextField == objectText)
		{
		[objectText resignFirstResponder];
		}
		
    return YES;
	}

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[ipLabel release];
	[ipText release];
	[portLabel release];
	[portText release];
	[startStop release];
	[listenConnect release];
	[objectLabel release];
	[objectText release];
	[startStopObject release];
	[logScroll release];
	
	
    [super dealloc];
}


@end
