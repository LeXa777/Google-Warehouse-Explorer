//
//  WonderlandRemoteAppDelegate.h
//  WonderlandRemote
//
//  Created by Morris Ford on 4/5/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WonderlandRemoteController;

@interface WonderlandRemoteAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	WonderlandRemoteController *wonderlandRemoteController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) WonderlandRemoteController *wonderlandRemoteController;

@end

