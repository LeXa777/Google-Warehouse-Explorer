print('Hello from javascript - mouse3 script  \r\n') ;
MyClass.initializeMessaging();
stateInt[0] = 0;
