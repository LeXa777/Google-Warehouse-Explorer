println('World coor');
MyClass.getWorldCoor();
println('X = ' + stateFloat[0]);
println('Y = ' + stateFloat[1]);
println('Z = ' + stateFloat[2]);

MyClass.buildAnimation("animation2");
MyClass.startTimer(50);
