print('Hello from javascript - startup script  \r\n') ;
MyClass.initializeMessaging();
stateInt[0] = 0;
