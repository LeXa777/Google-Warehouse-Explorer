<?php 
/*
$frame  = new Java('java.awt.Frame', 'PHP');
$button = new Java('java.awt.Button', 'Hello Java World!');

$frame->add('North', $button);
$frame->validate();
$frame->pack();
$frame->visible = True;

$thread = new Java('java.lang.Thread');
$thread->sleep(2000);

$frame->dispose();
*/

print "This is a test\n\r";
echo "This is a test\n\r";
$MyClass->testMethod("test test");
$MyClass->testMethod("Hello from startup.php script");
$MyClass->testMethod($stateString[0]);
$MyClass->setStateString("scroob", 0);   
$MyClass->setEventName("mouse", 0);
$MyClass->setEventName("mouse", 1);
$MyClass->setEventName("mouse", 2);
$MyClass->setEventName("mouse", 3);
$MyClass->setEventName("mouse", 4);
$MyClass->setEventName("mouse", 5);
$MyClass->setEventName("mouse", 6);
$MyClass->setEventName("mouse", 7);
$MyClass->setEventName("mouse", 8);
?>
