print("startup of startup for eval pass - event type = " + Event);

//function startup(MyClass)
//    {
    print("Hello from startup script ***************************************");
//    MyClass.setMouse1Name("mouse", "initial");
//    MyClass.setMouse1Name("mouse");
//    }

print("End of startup for eval pass");
