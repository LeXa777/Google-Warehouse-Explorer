print('Hello from javascript - mouse3 script  \r\n') ;
stateInt[0] = 0;
