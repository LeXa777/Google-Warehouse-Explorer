print('Hello from javascript - message script  \r\n') ;
print('Message received ' + stateString[0]);
