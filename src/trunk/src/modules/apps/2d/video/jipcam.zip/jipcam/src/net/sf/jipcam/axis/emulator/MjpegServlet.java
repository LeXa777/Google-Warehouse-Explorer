/**
 * jipCam : The Java IP Camera Project
 * Copyright (C) 2005-2006 Jason Thrasher
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.sf.jipcam.axis.emulator;

import net.sf.jipcam.axis.*;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.util.Enumeration;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 * Servlet to simulate the MJPEG stream coming from the camera.  This allows
 * use of a "canned" stream on the disk.  The stream is "played" in a loop for
 * the HTTP client.  The client should behave as if it's a continuous stream.
 *
 * The CGI request supports modifications to FPS.  This allows the client to run
 * at much higher FPS than the camera actually supports.  The timing of the response
 * MJPEG frames is not very accurate - but good enough up to around 100 FPS on a 2 GHz
 * computer.
 *
 * @author Jason Thrasher
 */
public class MjpegServlet extends HttpServlet {
	private static Logger mLog;
	private static final String CONTENT_TYPE = "multipart/x-mixed-replace; boundary=--myboundary";
	private static int DEFAULT_FPS = 10; //set in web.xml
	private File mMjpegFile; //set in web.xml

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		mLog = Logger.getLogger(this.getClass());

		String prefix = getServletContext().getRealPath("/");

		//mLog.log(Level.INFO, "context real path = " + prefix);
		String file = config.getInitParameter("mjpeg.file");

		if (file != null) {
			mMjpegFile = new File(prefix + file); //assume relative path

			//check that conf file found
			if (!mMjpegFile.exists()) {
				mMjpegFile = new File(file); //try the absolute path

				if (!mMjpegFile.exists()) {
					mLog.log(Level.FATAL, "mjpeg file not found: " + file);
					throw new ServletException("mjpeg file not found: " + file);
				}
			}
		} else {
			//no config file specified
			mLog.log(Level.FATAL, "mjpeg file not specified");
			throw new ServletException("mjpeg file not specified");
		}

		mLog.log(Level.INFO, "using " + mMjpegFile);

		DEFAULT_FPS = getIntegerParam(config.getInitParameter("mjpeg.fps"),
				DEFAULT_FPS);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		//log out the request parameters
		Enumeration names = request.getParameterNames();

		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			String value = request.getParameter(name);
			mLog.log(Level.INFO, "request parameter: " + name + "=" + value);
		}

		//try to get the frames per second value from the request		
		int fps = getIntegerParam(request.getParameter("req_fps"), -1);
		if (fps == -1) {
            //fall-back to "desired fps" if needed
			fps = getIntegerParam(request.getParameter("des_fps"), -1);
		}

        //calculate the milliseconds of delay to use between frames
		int deltaT = (fps <= 0) ? (1000 / DEFAULT_FPS) : (1000 / fps);
        mLog.log(Level.INFO, "Delta T between frames (ms): " + deltaT);

		//send response headers, this doesn't work the same with all servlet containers
		response.setContentType(CONTENT_TYPE);
		response.setHeader("Server", "Camd");
		response.setHeader("Connection", "Close");

		OutputStream out = new BufferedOutputStream(response.getOutputStream());
        MjpegInputStream in = new MjpegInputStream(new FileInputStream(mMjpegFile));
        MjpegFrame frame = null;    //next frame
        int byteCount = 0;  //count number of bytes written

        try {
        while(true) {
            try {
                frame = in.readMjpegFrame();
            } catch (IOException eof) {
                //we hit the end of the file, start over!
                in.close();
                in = new MjpegInputStream(new FileInputStream(mMjpegFile));
                continue;
            }
            out.write(frame.getBytes(), 0, frame.getLength());
            out.flush();
            Thread.sleep(deltaT);
        }
		} catch (IOException ioe) {
			//usually due to client disconnect
			mLog.log(Level.FATAL, "lost client connection");
		} catch (InterruptedException ie) {
			mLog.log(Level.WARN, ie.getMessage());
		} catch (Exception e) {
			mLog.log(Level.ERROR, e.getMessage());
		} finally {
            try {
                out.close();
            } catch(Exception e) {
                e.printStackTrace();
            }
            try {
                in.close();
            } catch(Exception e) {
                e.printStackTrace();
            }
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		doGet(request, response);
	}

	/**
	 * Utility method to uniformly parse numbers
	 */
	private int getIntegerParam(String value, int vDefault) {
		int val = vDefault;

		try {
			val = Integer.parseInt(value);
		} catch (Exception e) {
			mLog.log(Level.WARN,
				"failed to parse integer: " + value + " using default: " +
				vDefault);
		}

		return val;
	}
}
