/**
 * jipCam : The Java IP Camera Project
 * Copyright (C) 2005-2006 Jason Thrasher
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package net.sf.jipcam.axis.tools;

import net.sf.jipcam.axis.media.protocol.http.DataSource;

import java.awt.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.lang.String;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.Vector;

import javax.media.*;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;


/**
  * This is a Java Applet that demonstrates how to create a simple
  * media player with a media event listener. It will play the
  * media clip right away and continuously loop.
  *
  * <!-- Sample HTML
  * <applet code="MjpegApplet" width="352" height="240">
  * <param name="mjpeg" value="/axis-cgi/mjpg/video.cgi?req_fps=10">
  * <param name="width" value="352">
  * <param name="height" value="240">
  * <param name="fps" value="10">
  * </applet>
  * -->
  */
public class MjpegApplet extends JApplet {
	//boolean firstTime = true;
	//long CachingSize = 0L;
	//Panel panel = null;
	//int controlPanelHeight = 0;
	int videoWidth = 352;
	int videoHeight = 240;
	int mFps = 10; //frames per second
	URL mUrl = null;
	AxisPlayer mPlayer;
	JPanel mMainPanel = new JPanel(new BorderLayout(0, 0));

	public MjpegApplet() {
		System.out.println("MjpegApplet constructed.");

		//empty constructor for use as Applet 
	}

	public MjpegApplet(int width, int height, int fps, URL url) {
		this.videoWidth = width;
		this.videoHeight = height;
		this.mFps = fps;
		mUrl = url;
		jbinit();
	}

	/**
	 * Read the applet file parameter and create the media
	 * player.
	 */
	public void init() {
		try {
			videoWidth = Integer.parseInt(getParameter("width"));
			videoHeight = Integer.parseInt(getParameter("height"));
			mFps = Integer.parseInt(getParameter("fps"));
			mUrl = new URL(getDocumentBase(), getParameter("mjpeg"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("width = " + videoWidth);
		System.out.println("height = " + videoHeight);
		System.out.println("fps = " + mFps);
		System.out.println("url = " + mUrl.toExternalForm());

		jbinit();
	}

	public void jbinit() {
		setLayout(new BorderLayout());
		setBackground(Color.white);
		setBounds(0, 0, videoWidth, videoHeight);
	}

	/**
	 * Start media file playback. This function is called the
	 * first time that the Applet runs and every
	 * time the user re-enters the page.
	 */
	public void start() {
		System.out.println("Applet.start() is called");

		// Call start() to prefetch and start the player.
		try {
			mPlayer = new AxisPlayer(videoWidth, videoHeight, mFps,
					mUrl.openStream());
			add(mPlayer, BorderLayout.CENTER);
		} catch (Exception e) {
			Fatal(e.getMessage());
		}

		if (mPlayer != null) {
			mPlayer.start();
		}
	}

	/**
	 * Stop media file playback and release resource before
	 * leaving the page.
	 */
	public void stop() {
		System.out.println("Applet.stop() is called");

		if (mPlayer != null) {
			mPlayer.stop();
			mPlayer.destroy();
		}
	}

	public void destroy() {
		System.out.println("Applet.destroy() is called");
		mPlayer.destroy();
	}

	void Fatal(String s) {
		// Applications will make various choices about what
		// to do here. We print a message
		System.err.println("FATAL ERROR: " + s);
		throw new Error(s); // Invoke the uncaught exception

		// handler System.exit() is another
		// choice.
	}

	public static void main(String[] args) {
		try {
			MjpegApplet applet = new MjpegApplet(320, 240, 10,
					new URL("http://127.0.0.1:8080/eyeq/camera-proxy?camid=5"));

			//			MjpegApplet applet = new MjpegApplet(352, 240, 10, new File("D:/dev/axis/data/lost_girl.mjpeg").toURL());
			JFrame frame = new JFrame("MjpegApplet Test");
			frame.pack();
			frame.setVisible(true);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setContentPane(applet);
			frame.setSize(400, 500);

			applet.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
