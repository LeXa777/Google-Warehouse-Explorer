jipCam "The Java IP Camera Project"

jipCam is licensed under the LGPL.  Please see the license.txt file for further information.

The jipCam homepage is located here: http://jipcam.sourceforge.net

jipCam provides a Java Media Framework based datasource to read from different Internet Protocol based video cameras. A computer with Java, and the Java Media Framework, can install jipCam as a JMF protocol handler to allow an IP-based camera's video to become available for processing in JMF. This library is intended for use by developers seeking to build applications using IP-based video cameras on a Java platform.

